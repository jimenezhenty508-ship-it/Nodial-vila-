package com.avila.nodial

import android.net.Uri
import android.telecom.CallRedirectionService
import android.telecom.PhoneAccountHandle

class OutgoingBlockService : CallRedirectionService() {
    override fun onPlaceCall(
        handle: Uri,
        initialPhoneAccount: PhoneAccountHandle,
        allowInteractiveResponse: Boolean
    ) {
        val number = handle.schemeSpecificPart
        if (BlockedNumbers.contains(this, number)) {
            cancelCall()
        } else {
            placeCallUnmodified()
        }
    }
}
