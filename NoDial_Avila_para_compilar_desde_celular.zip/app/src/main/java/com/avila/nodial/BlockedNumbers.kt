package com.avila.nodial

import android.content.Context

object BlockedNumbers {
    private const val PREFS = "nodial_avila"
    private const val KEY = "blocked"

    fun all(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY, emptySet())?.toSet() ?: emptySet()

    fun add(context: Context, number: String) {
        val values = all(context).toMutableSet()
        values.add(number.trim())
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY, values).apply()
    }

    fun remove(context: Context, number: String) {
        val values = all(context).toMutableSet()
        values.remove(number)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY, values).apply()
    }

    fun contains(context: Context, number: String?): Boolean {
        if (number.isNullOrBlank()) return false
        val digits = number.filter { it.isDigit() }
        return all(context).any { saved ->
            val candidate = saved.filter { it.isDigit() }
            candidate == digits ||
                (candidate.length >= 7 && digits.length >= 7 &&
                 candidate.takeLast(9) == digits.takeLast(9))
        }
    }
}
