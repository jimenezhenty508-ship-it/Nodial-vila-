package com.avila.nodial

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var outgoingStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) refresh()
        if (::status.isInitialized) updateStatuses()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 20)
            setBackgroundColor(0xFFF5F5F5.toInt())
        }
        val title = TextView(this).apply {
            text = "NoDial Ávila"
            textSize = 28f
            setTextColor(0xFFB71C1C.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        status = TextView(this).apply { textSize = 14f; setPadding(0, 12, 0, 4) }
        outgoingStatus = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, 10) }

        val incoming = Button(this).apply {
            text = "ACTIVAR BLOQUEO DE ENTRADA"
            setOnClickListener { requestRole(RoleManager.ROLE_CALL_SCREENING) }
        }
        val outgoing = Button(this).apply {
            text = "ACTIVAR BLOQUEO DE SALIDA"
            setOnClickListener { requestRole(RoleManager.ROLE_CALL_REDIRECTION) }
        }
        val info = TextView(this).apply {
            text = "Agrega números para bloquear sus llamadas entrantes y, si Android admite el servicio en tu teléfono, impedir que llames a esos números."
            textSize = 14f
            setPadding(0, 10, 0, 14)
        }
        val input = EditText(this).apply {
            hint = "Número con código de país si corresponde"
            inputType = 3
        }
        val add = Button(this).apply {
            text = "AGREGAR A LA LISTA NEGRA"
            setOnClickListener {
                val value = input.text.toString().trim()
                if (value.count { it.isDigit() } < 7) {
                    Toast.makeText(this@MainActivity, "Ingresa un número válido", Toast.LENGTH_SHORT).show()
                } else {
                    BlockedNumbers.add(this@MainActivity, value)
                    input.text.clear()
                    refresh()
                }
            }
        }
        val heading = TextView(this).apply {
            text = "NÚMEROS BLOQUEADOS"
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 16, 0, 8)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        root.addView(title)
        root.addView(status)
        root.addView(outgoingStatus)
        root.addView(incoming)
        root.addView(outgoing)
        root.addView(info)
        root.addView(input, ViewGroup.LayoutParams(-1, -2))
        root.addView(add)
        root.addView(heading)
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
        updateStatuses()
    }

    private fun requestRole(role: String) {
        val manager = getSystemService(Context.ROLE_SERVICE) as RoleManager
        if (!manager.isRoleAvailable(role)) {
            Toast.makeText(this, "Esta versión de Android no ofrece este permiso.", Toast.LENGTH_LONG).show()
            return
        }
        if (manager.isRoleHeld(role)) {
            Toast.makeText(this, "Este bloqueo ya está activado.", Toast.LENGTH_SHORT).show()
        } else {
            startActivityForResult(manager.createRequestRoleIntent(role),
                if (role == RoleManager.ROLE_CALL_SCREENING) 10 else 11)
        }
    }

    private fun updateStatuses() {
        val manager = getSystemService(Context.ROLE_SERVICE) as RoleManager
        status.text = if (manager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING))
            "Llamadas entrantes: ACTIVADO" else "Llamadas entrantes: pendiente de activar"
        outgoingStatus.text = if (manager.isRoleHeld(RoleManager.ROLE_CALL_REDIRECTION))
            "Llamadas salientes: ACTIVADO" else "Llamadas salientes: pendiente de activar"
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val numbers = BlockedNumbers.all(this).sorted()
        if (numbers.isEmpty()) {
            list.addView(TextView(this).apply { text = "No hay números agregados."; textSize = 15f })
        }
        numbers.forEach { number ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply {
                text = number
                textSize = 17f
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Quitar"
                setOnClickListener {
                    BlockedNumbers.remove(this@MainActivity, number)
                    refresh()
                }
            })
            list.addView(row)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        updateStatuses()
    }
}
