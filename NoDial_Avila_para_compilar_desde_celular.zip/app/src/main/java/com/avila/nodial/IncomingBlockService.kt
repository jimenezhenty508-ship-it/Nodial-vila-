package com.avila.nodial

import android.telecom.Call
import android.telecom.CallScreeningService

class IncomingBlockService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        val number = details.handle?.schemeSpecificPart
        val blocked = BlockedNumbers.contains(this, number)
        val response = CallResponse.Builder()
            .setDisallowCall(blocked)
            .setRejectCall(blocked)
            .setSkipCallLog(blocked)
            .setSkipNotification(blocked)
            .build()
        respondToCall(details, response)
    }
}
